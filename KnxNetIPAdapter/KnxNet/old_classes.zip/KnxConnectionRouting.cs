﻿using Windows.Networking;
using Spark.Universal.Net;


namespace AdapterLib.KnxNet
{
    /// <summary>
    ///     Class that controls a Routing KNX connection, a routing connection is UDP based and has no state.
    ///     This class will bind to a multicast address to listen for events and send actions and requests to
    ///     that same address
    /// </summary>
    internal class KnxConnectionRouting : KnxConnection
    {
        private UdpClient _udpClient = null;

        public KnxConnectionRouting()
        {
            _udpClient = new UdpClient();
        }

        /// <summary>
        ///     Start the connection
        /// </summary>
        public override void Connect(string host = "224.0.23.12", int port = 3671)
        {
            _udpClient.Close();
            _udpClient.BindSocket("3671");

            var hostName = new HostName(host);
            _udpClient.Connect(hostName, port.ToString());
            _udpClient.JoinMulticastGroup(hostName);                              

            this.KnxReceiver = new KnxReceiverRouting(this, _udpClient);
            this.KnxSender = new KnxSenderRouting(this, _udpClient);
            this.KnxReceiver.Start();

            this.Connected();
        }

        /// <summary>
        ///     Stop the connection
        /// </summary>
        public override void Disconnect()
        {
            this.KnxReceiver.Stop();
            _udpClient.Close();

            this.Disconnected();
        }
    }
}
