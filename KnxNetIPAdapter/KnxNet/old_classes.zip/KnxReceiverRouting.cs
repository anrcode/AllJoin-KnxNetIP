﻿using System;
using Spark.Universal.Net;


namespace AdapterLib.KnxNet
{
    internal class KnxReceiverRouting : KnxReceiver
    {
        private UdpClient _udpClient;

        internal KnxReceiverRouting(KnxConnection connection, UdpClient udpClient) : base(connection)
        {
            _udpClient = udpClient;
        }

        public override void Start()
        {
            _udpClient.DataReceived += SocketDataReceived;
        }

        public override void Stop()
        {
             _udpClient.DataReceived -= SocketDataReceived;
        }

        private void SocketDataReceived(object sender, DataReceivedEventArgs e)
        {
            byte[] datagram = e.Data;

            // HEADER
            var knxDatagram = new KnxCEMI
            {
                header_length = datagram[0],
                protocol_version = datagram[1],
                service_type = new[] { datagram[2], datagram[3] },
                total_length = datagram[4] + datagram[5]
            };

            var cemi = new byte[datagram.Length - 6];
            Array.Copy(datagram, 6, cemi, 0, datagram.Length - 6);

            ProcessCEMI(knxDatagram, cemi);
        }
    }
}
