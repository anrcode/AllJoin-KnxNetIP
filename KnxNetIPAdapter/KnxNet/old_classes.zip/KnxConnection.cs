﻿using System;
using AdapterLib.KnxNet.DPT;


namespace AdapterLib.KnxNet
{
   
    /// <summary>
    ///     Base class that controls the KNX connection, implemented by KnxConnectionRouting and KnxConnetionTunneling
    /// </summary>
    internal abstract class KnxConnection
    {
        public event EventHandler<EventArgs> KnxConnected;

        public event EventHandler<EventArgs> KnxDisconnected;

        public event EventHandler<KnxEventArgs> KnxEvent;

        public event EventHandler<KnxEventArgs> KnxStatus;

        internal KnxReceiver KnxReceiver { get; set; }

        internal KnxSender KnxSender { get; set; }

        /// <summary>
        ///     Configure this paramenter based on the KNX installation:
        ///     - true: 3-level group address: main/middle/sub(5/3/8 bits)
        ///     - false: 2-level group address: main/sub (5/11 bits)
        ///     Default: true
        /// </summary>
        public bool ThreeLevelGroupAddressing { get; set; }

        /// <summary>
        ///     Some KNX Routers/Interfaces might need this parameter defined, some need this to be 0x29.
        ///     Default: 0x00
        /// </summary>
        public byte ActionMessageCode { get; set; }

        //private readonly KnxLockManager _lockManager = new KnxLockManager();

        /// <summary>
        ///     Create a new KNX Connection to specified host and port
        /// </summary>
        /// <param name="host">Host to connect</param>
        /// <param name="port">Port to use</param>
        protected KnxConnection()
        {
            ActionMessageCode = 0x00;
            ThreeLevelGroupAddressing = true;
        }     

        /// <summary>
        ///     Start the connection
        /// </summary>
        public abstract void Connect(string host, int port);

        /// <summary>
        ///     Stop the connection
        /// </summary>
        public abstract void Disconnect();

        /// <summary>
        ///     Event triggered by implementing class to notify that the connection has been established
        /// </summary>
        internal virtual void Connected()
        {
            //_lockManager.UnlockConnection();

            if (this.KnxConnected != null)
            {
                this.KnxConnected(this, EventArgs.Empty);
            }
        }

        /// <summary>
        ///     Event triggered by implementing class to notify that the connection has been established
        /// </summary>
        internal virtual void Disconnected()
        {
            //_lockManager.LockConnection();

            if (this.KnxDisconnected != null)
            {
                this.KnxDisconnected(this, EventArgs.Empty);
            }
        }

        internal void Event(string address, byte[] data)
        {
            if(this.KnxEvent != null)
            {
                this.KnxEvent(this, new KnxEventArgs { Address = address, Data = data });
            }
        }

        internal void Status(string address, byte[] data)
        {
            if (this.KnxStatus != null)
            {
                this.KnxStatus(this, new KnxEventArgs { Address = address, Data = data });
            }
        }

        /// <summary>
        ///     Send a bit value as data to specified address
        /// </summary>
        /// <param name="address">KNX Address</param>
        /// <param name="data">Bit value</param>
        /// <exception cref="InvalidKnxDataException"></exception>
        //public void Action(string address, bool data)
        //{
        //    byte[] val;

        //    try
        //    {
        //        val = new[] {Convert.ToByte(data)};
        //    }
        //    catch
        //    {
        //        throw new InvalidKnxDataException(data.ToString());
        //    }

        //    if (val == null)
        //        throw new InvalidKnxDataException(data.ToString());

        //    Action(address, val);
        //}

        /// <summary>
        ///     Send a string value as data to specified address
        /// </summary>
        /// <param name="address">KNX Address</param>
        /// <param name="data">String value</param>
        /// <exception cref="InvalidKnxDataException"></exception>
        //public void Action(string address, string data)
        //{
        //    byte[] val;
        //    try
        //    {
        //        val = Encoding.ASCII.GetBytes(data);
        //    }
        //    catch
        //    {
        //        throw new InvalidKnxDataException(data);
        //    }

        //    if (val == null)
        //        throw new InvalidKnxDataException(data);

        //    Action(address, val);
        //}

        /// <summary>
        ///     Send an int value as data to specified address
        /// </summary>
        /// <param name="address">KNX Address</param>
        /// <param name="data">Int value</param>
        /// <exception cref="InvalidKnxDataException"></exception>
        //public void Action(string address, int data)
        //{
        //    var val = new byte[2];
        //    if (data <= 255)
        //    {
        //        val[0] = 0x00;
        //        val[1] = (byte) data;
        //    }
        //    else if (data <= 65535)
        //    {
        //        val[0] = (byte) data;
        //        val[1] = (byte) (data >> 8);
        //    }
        //    else
        //    {
        //        // allowing only positive integers less than 65535 (2 bytes), maybe it is incorrect...???
        //        throw new InvalidKnxDataException(data.ToString());
        //    }

        //    if (val == null)
        //        throw new InvalidKnxDataException(data.ToString());

        //    Action(address, val);
        //}

        /// <summary>
        ///     Send a byte value as data to specified address
        /// </summary>
        /// <param name="address">KNX Address</param>
        /// <param name="data">byte value</param>
        //public void Action(string address, byte data)
        //{
        //    Action(address, new byte[] {0x00, data});
        //}

        /// <summary>
        ///     Send a byte array value as data to specified address
        /// </summary>
        /// <param name="address">KNX Address</param>
        /// <param name="data">Byte array value</param>
        public void Action(string address, byte[] data)
        {
            //_lockManager.PerformLockedOperation(() => KnxSender.Action(address, data));
        }

        // TODO: It would be good to make a type for address, to make sure not any random string can be passed in
        /// <summary>
        ///     Send a request to KNX asking for specified address current status
        /// </summary>
        /// <param name="address"></param>
        public void RequestStatus(string address)
        {
            //_lockManager.PerformLockedOperation(() => KnxSender.RequestStatus(address));
        }

        /// <summary>
        ///     Convert a value received from KNX using datapoint translator, e.g.,
        ///     get a temperature value in Celsius
        /// </summary>
        /// <param name="type">Datapoint type, e.g.: 9.001</param>
        /// <param name="data">Data to convert</param>
        /// <returns></returns>
        public object FromDataPoint(string type, byte[] data)
        {
            return DataPointTranslator.Instance.FromASDU(type, data);
        }

        /// <summary>
        ///     Convert a value to send to KNX using datapoint translator, e.g.,
        ///     get a temperature value in Celsius in a byte representation
        /// </summary>
        /// <param name="type">Datapoint type, e.g.: 9.001</param>
        /// <param name="value">Value to convert</param>
        /// <returns></returns>
        public byte[] ToDataPoint(string type, object value)
        {
            return DataPointTranslator.Instance.ToASDU(type, value);
        }
    }
}
